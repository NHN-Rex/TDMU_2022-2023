﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hotel_manager
{
    public class Const
    {
        public static string loaitaikhoan;
        public static string tenkhachhang;
        public static string tenphong;
        public static string sotiencanthanhtoan;
        public static string ngaythanhtoan;
        public static bool check = false;
        public static bool tatnutluu = true;
        public static int idtaikhoan;
        public static bool loadgridview = false;
    }
}

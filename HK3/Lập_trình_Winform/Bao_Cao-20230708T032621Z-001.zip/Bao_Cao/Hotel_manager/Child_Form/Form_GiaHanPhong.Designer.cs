﻿namespace Hotel_manager.Child_Form
{
    partial class Form_GiaHanPhong
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            grvThuephong = new DataGridView();
            txtTenphong = new TextBox();
            txtTenloaiphong = new TextBox();
            txtKhachhang = new TextBox();
            ckbTrangthai = new CheckBox();
            btnTim = new Button();
            lbSotiencantra = new Label();
            label7 = new Label();
            label4 = new Label();
            label6 = new Label();
            txtNgaytra = new TextBox();
            btnLuu = new Button();
            btnThanhtoan = new Button();
            panel2 = new Panel();
            btnTraphong = new Button();
            label2 = new Label();
            label3 = new Label();
            txtSotienthanhtoan = new TextBox();
            txtID = new TextBox();
            txtNgaythue = new TextBox();
            label5 = new Label();
            label1 = new Label();
            txtTiendatcoc = new TextBox();
            panel1 = new Panel();
            ((System.ComponentModel.ISupportInitialize)grvThuephong).BeginInit();
            panel2.SuspendLayout();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // grvThuephong
            // 
            grvThuephong.AllowUserToOrderColumns = true;
            grvThuephong.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            grvThuephong.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            grvThuephong.BackgroundColor = SystemColors.ButtonFace;
            grvThuephong.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            grvThuephong.Location = new Point(12, 226);
            grvThuephong.MultiSelect = false;
            grvThuephong.Name = "grvThuephong";
            grvThuephong.RowTemplate.Height = 25;
            grvThuephong.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            grvThuephong.Size = new Size(776, 220);
            grvThuephong.TabIndex = 97;
            // 
            // txtTenphong
            // 
            txtTenphong.Location = new Point(175, 59);
            txtTenphong.Name = "txtTenphong";
            txtTenphong.Size = new Size(246, 23);
            txtTenphong.TabIndex = 98;
            // 
            // txtTenloaiphong
            // 
            txtTenloaiphong.Location = new Point(109, 59);
            txtTenloaiphong.Name = "txtTenloaiphong";
            txtTenloaiphong.Size = new Size(60, 23);
            txtTenloaiphong.TabIndex = 98;
            // 
            // txtKhachhang
            // 
            txtKhachhang.Location = new Point(109, 30);
            txtKhachhang.Name = "txtKhachhang";
            txtKhachhang.Size = new Size(312, 23);
            txtKhachhang.TabIndex = 98;
            // 
            // ckbTrangthai
            // 
            ckbTrangthai.AutoSize = true;
            ckbTrangthai.Location = new Point(317, 149);
            ckbTrangthai.Name = "ckbTrangthai";
            ckbTrangthai.Size = new Size(104, 19);
            ckbTrangthai.TabIndex = 91;
            ckbTrangthai.Text = "Đã Thanh Toán";
            ckbTrangthai.UseVisualStyleBackColor = true;
            // 
            // btnTim
            // 
            btnTim.Anchor = AnchorStyles.None;
            btnTim.Location = new Point(385, 3);
            btnTim.Name = "btnTim";
            btnTim.Size = new Size(38, 23);
            btnTim.TabIndex = 95;
            btnTim.Text = "Tìm";
            btnTim.UseVisualStyleBackColor = true;
            // 
            // lbSotiencantra
            // 
            lbSotiencantra.Anchor = AnchorStyles.None;
            lbSotiencantra.AutoSize = true;
            lbSotiencantra.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Regular, GraphicsUnit.Point);
            lbSotiencantra.Location = new Point(17, 146);
            lbSotiencantra.Name = "lbSotiencantra";
            lbSotiencantra.Size = new Size(152, 20);
            lbSotiencantra.TabIndex = 93;
            lbSotiencantra.Text = "Số Tiền Thanh Toán";
            // 
            // label7
            // 
            label7.Anchor = AnchorStyles.None;
            label7.AutoSize = true;
            label7.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label7.Location = new Point(246, 116);
            label7.Name = "label7";
            label7.Size = new Size(72, 20);
            label7.TabIndex = 93;
            label7.Text = "Ngày Trả";
            // 
            // label4
            // 
            label4.Anchor = AnchorStyles.None;
            label4.AutoSize = true;
            label4.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label4.Location = new Point(18, 116);
            label4.Name = "label4";
            label4.Size = new Size(85, 20);
            label4.TabIndex = 93;
            label4.Text = "Ngày Thuê";
            // 
            // label6
            // 
            label6.Anchor = AnchorStyles.None;
            label6.AutoSize = true;
            label6.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label6.Location = new Point(77, 6);
            label6.Name = "label6";
            label6.Size = new Size(26, 20);
            label6.TabIndex = 93;
            label6.Text = "ID";
            // 
            // txtNgaytra
            // 
            txtNgaytra.Anchor = AnchorStyles.None;
            txtNgaytra.Location = new Point(332, 115);
            txtNgaytra.Name = "txtNgaytra";
            txtNgaytra.Size = new Size(89, 23);
            txtNgaytra.TabIndex = 87;
            // 
            // btnLuu
            // 
            btnLuu.Anchor = AnchorStyles.None;
            btnLuu.BackColor = Color.White;
            btnLuu.Enabled = false;
            btnLuu.FlatStyle = FlatStyle.System;
            btnLuu.Location = new Point(247, 28);
            btnLuu.Name = "btnLuu";
            btnLuu.Size = new Size(74, 31);
            btnLuu.TabIndex = 88;
            btnLuu.Text = "Xác Nhận";
            btnLuu.UseVisualStyleBackColor = false;
            // 
            // btnThanhtoan
            // 
            btnThanhtoan.Anchor = AnchorStyles.None;
            btnThanhtoan.ImageAlign = ContentAlignment.MiddleLeft;
            btnThanhtoan.Location = new Point(64, 28);
            btnThanhtoan.Name = "btnThanhtoan";
            btnThanhtoan.Size = new Size(97, 31);
            btnThanhtoan.TabIndex = 87;
            btnThanhtoan.Text = "Thanh Toán";
            btnThanhtoan.UseVisualStyleBackColor = true;
            // 
            // panel2
            // 
            panel2.Controls.Add(btnLuu);
            panel2.Controls.Add(btnThanhtoan);
            panel2.Controls.Add(btnTraphong);
            panel2.Location = new Point(464, 154);
            panel2.Name = "panel2";
            panel2.Size = new Size(324, 66);
            panel2.TabIndex = 96;
            // 
            // btnTraphong
            // 
            btnTraphong.Anchor = AnchorStyles.None;
            btnTraphong.ImageAlign = ContentAlignment.MiddleLeft;
            btnTraphong.Location = new Point(167, 28);
            btnTraphong.Name = "btnTraphong";
            btnTraphong.Size = new Size(74, 31);
            btnTraphong.TabIndex = 87;
            btnTraphong.Text = "Gia Hạn";
            btnTraphong.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            label2.Anchor = AnchorStyles.Top;
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point);
            label2.Location = new Point(286, 5);
            label2.Name = "label2";
            label2.Size = new Size(265, 25);
            label2.TabIndex = 95;
            label2.Text = "Danh Sách Tác Vụ Trả Phòng";
            // 
            // label3
            // 
            label3.Anchor = AnchorStyles.None;
            label3.AutoSize = true;
            label3.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label3.Location = new Point(2, 87);
            label3.Name = "label3";
            label3.Size = new Size(101, 20);
            label3.TabIndex = 93;
            label3.Text = "Tiền Đặt Cọc";
            // 
            // txtSotienthanhtoan
            // 
            txtSotienthanhtoan.Anchor = AnchorStyles.None;
            txtSotienthanhtoan.Location = new Point(175, 145);
            txtSotienthanhtoan.Name = "txtSotienthanhtoan";
            txtSotienthanhtoan.Size = new Size(121, 23);
            txtSotienthanhtoan.TabIndex = 87;
            // 
            // txtID
            // 
            txtID.Anchor = AnchorStyles.None;
            txtID.Location = new Point(109, 3);
            txtID.Name = "txtID";
            txtID.Size = new Size(270, 23);
            txtID.TabIndex = 87;
            // 
            // txtNgaythue
            // 
            txtNgaythue.Anchor = AnchorStyles.None;
            txtNgaythue.Location = new Point(109, 116);
            txtNgaythue.Name = "txtNgaythue";
            txtNgaythue.Size = new Size(89, 23);
            txtNgaythue.TabIndex = 87;
            // 
            // label5
            // 
            label5.Anchor = AnchorStyles.None;
            label5.AutoSize = true;
            label5.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label5.Location = new Point(48, 58);
            label5.Name = "label5";
            label5.Size = new Size(55, 20);
            label5.TabIndex = 93;
            label5.Text = "Phòng";
            // 
            // label1
            // 
            label1.Anchor = AnchorStyles.None;
            label1.AutoSize = true;
            label1.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label1.Location = new Point(6, 33);
            label1.Name = "label1";
            label1.Size = new Size(97, 20);
            label1.TabIndex = 89;
            label1.Text = "Khách Hàng";
            // 
            // txtTiendatcoc
            // 
            txtTiendatcoc.Anchor = AnchorStyles.None;
            txtTiendatcoc.Location = new Point(109, 88);
            txtTiendatcoc.Name = "txtTiendatcoc";
            txtTiendatcoc.Size = new Size(312, 23);
            txtTiendatcoc.TabIndex = 87;
            // 
            // panel1
            // 
            panel1.Controls.Add(txtTenphong);
            panel1.Controls.Add(txtTenloaiphong);
            panel1.Controls.Add(txtKhachhang);
            panel1.Controls.Add(ckbTrangthai);
            panel1.Controls.Add(btnTim);
            panel1.Controls.Add(lbSotiencantra);
            panel1.Controls.Add(label7);
            panel1.Controls.Add(label4);
            panel1.Controls.Add(label6);
            panel1.Controls.Add(txtNgaytra);
            panel1.Controls.Add(label3);
            panel1.Controls.Add(txtSotienthanhtoan);
            panel1.Controls.Add(txtID);
            panel1.Controls.Add(txtNgaythue);
            panel1.Controls.Add(txtTiendatcoc);
            panel1.Controls.Add(label5);
            panel1.Controls.Add(label1);
            panel1.Location = new Point(24, 37);
            panel1.Name = "panel1";
            panel1.Size = new Size(601, 183);
            panel1.TabIndex = 94;
            // 
            // Form_GiaHanPhong
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(102, 153, 204);
            ClientSize = new Size(800, 450);
            Controls.Add(grvThuephong);
            Controls.Add(panel2);
            Controls.Add(label2);
            Controls.Add(panel1);
            Name = "Form_GiaHanPhong";
            Text = "Form_GiaHanPhong";
            ((System.ComponentModel.ISupportInitialize)grvThuephong).EndInit();
            panel2.ResumeLayout(false);
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView grvThuephong;
        private TextBox txtTenphong;
        private TextBox txtTenloaiphong;
        private TextBox txtKhachhang;
        private CheckBox ckbTrangthai;
        private Button btnTim;
        private Label lbSotiencantra;
        private Label label7;
        private Label label4;
        private Label label6;
        private TextBox txtNgaytra;
        private Button btnLuu;
        private Button btnThanhtoan;
        private Panel panel2;
        private Button btnTraphong;
        private Label label2;
        private Label label3;
        private TextBox txtSotienthanhtoan;
        private TextBox txtID;
        private TextBox txtNgaythue;
        private Label label5;
        private Label label1;
        private TextBox txtTiendatcoc;
        private Panel panel1;
    }
}